declare const _default: {
    create(conf: any): any;
    get(conf: any): any;
    set(conf: any, val: any): void;
};
export default _default;
