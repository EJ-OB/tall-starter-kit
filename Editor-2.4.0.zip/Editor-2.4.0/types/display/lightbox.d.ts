import { IDisplayController } from '../model/displayController';
declare const self: IDisplayController;
export default self;
