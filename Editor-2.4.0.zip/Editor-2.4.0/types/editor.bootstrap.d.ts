
import DataTable from '@datatables.net/editor';

export default DataTable;
export * from '@datatables.net/editor';
